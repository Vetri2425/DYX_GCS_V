# FIELD REFERENCE CARD: DXF → Mission in 10 Minutes
## On-Site Georeferencing with Android Tab + GPS Torch

---

## WHAT YOU HAVE
✓ Android tablet with DYX_GCS app  
✓ GPS torch (RTK capable)  
✓ CAD file (DXF) of parking lot  
✓ Client showing starting point  
✗ NO laptop, NO desktop, NO Jetson

---

## THE CONCEPT (30 seconds)

```
GPS Point 1 ─────────────────── GPS Point 2
 (Start)                          (Corner)
   ↓                                 ↓
   └──── Measure 2 points ────────┘
   
CAD Point 1 ─────────────────── CAD Point 2
 (0,0)                        (X,Y in mm)
   ↓                                 ↓
   └──── Find same corners ────────┘

AFFINE MATH:
├─ Calculate SCALE = GPS_distance / CAD_distance
├─ Calculate ROTATION = GPS_bearing - CAD_angle  
└─ Apply to ALL CAD points → Mission waypoints
```

---

## FIELD WORKFLOW: 7 STEPS (10 MIN TOTAL)

### STEP 1: Prepare (1 min)
```
☐ Open DYX_GCS app on tablet
☐ Load CAD file (in app)
☐ Ensure GPS torch is ready
☐ Have client show you first point (physically)
```

### STEP 2: Capture GPS Point 1 (2 min)
```
ACTION:
  1. Tap "Mission Setup" → "GPS Capture"
  2. Stand at location client shows
  3. Hold GPS torch up (clear sky view)
  4. Tap "Capture Point 1"
  5. Wait 10 seconds for fix
  
RESULT:
  Tablet records: Lat 13.082705, Lon 80.270890
  ✓ Point 1 locked
```

### STEP 3: Capture GPS Point 2 (2 min)
```
ACTION:
  1. Walk to opposite corner of parking lot
  2. Hold GPS torch up (clear sky)
  3. Tap "Capture Point 2"
  4. Wait 10 seconds
  
RESULT:
  Tablet records: Lat 13.082980, Lon 80.271120
  ✓ Point 2 locked
  
APP CALCULATES:
  Distance = 37.5 meters
  Bearing = 42.3°
```

### STEP 4: Load CAD & Find Same Points (2 min)
```
ACTION:
  1. In app: "Load CAD Drawing"
  2. CAD displays parking lot (you see it on screen)
  3. Identify first corner (where you stood)
     └─ Tap on that point in CAD
     └─ App records: CAD_x = 0, CAD_y = 0
  
  4. Identify second corner (where you walked)
     └─ Tap on that point in CAD  
     └─ App records: CAD_x = 3750, CAD_y = 2800 (in mm)
     
RESULT:
  CAD distance = √(3750² + 2800²) = 4712 mm = 4.712 m
```

### STEP 5: Auto-Calculate Transform (30 sec)
```
APP DOES (automatic):
  ├─ SCALE = 37.5 m / 4.712 m = 7.96
  ├─ ROTATION = 42.3° - atan2(2800,3750) = 42.3° - 36.6° = 5.7°
  ├─ Applies to ALL CAD points:
  │  └─ Example: CAD point (1000, 1000) → GPS (13.08301, 80.27098)
  ├─ Extracts all lines/polylines from DXF
  └─ Generates 250+ waypoints
  
✓ Transform complete
```

### STEP 6: Review on Map (1 min)
```
TABLET SHOWS:
  ├─ Map with satellite view
  ├─ Parking lot drawing overlaid
  ├─ Start point marked (RED)
  ├─ Path marked (BLUE)
  ├─ Stats:
  │  ├─ Total distance: 1250 meters
  │  ├─ Waypoints: 251
  │  ├─ Est. time: 42 min (at 0.5 m/s)
  │  └─ Accuracy: ±10 cm (RTK)
  
YOUR CHECK:
  ☐ Does drawing align with parking lot?
  ☐ Are lines in correct direction?
  ☐ Do corners look right?
  
ACTION: Tap "✓ Approved"
```

### STEP 7: Send to Rover (1 min)
```
ACTION:
  1. Tap "Export Mission"
  2. Choose: "Send via WiFi" or "Save File"
  3. If WiFi:
     └─ Rover receives mission auto
  4. If File:
     └─ Transfer via USB later
     
RESULT:
  ✓ Rover receives mission
  ✓ Ready to execute
  
ROVER EXECUTION:
  1. Arm rover
  2. Set to AUTO mode
  3. Mission starts automatically
  4. Follows waypoints with RTK accuracy
```

---

## QUICK REFERENCE TABLE

| What | Where | Time |
|------|-------|------|
| Capture GPS Point 1 | Standing at start | 2 min |
| Capture GPS Point 2 | Walking to corner | 2 min |
| Load & identify CAD points | On tablet | 2 min |
| Review transform result | Map display | 1 min |
| Export & send to rover | Tap button | 1 min |
| **TOTAL** | | **8 min** |

---

## AFFINE TRANSFORMATION FORMULA (If Manual Calc)

```
If app doesn't auto-calculate:

1. SCALE FACTOR:
   GPS_distance = √[(lat2-lat1)² + (lon2-lon1)² × 111000²]
   CAD_distance = √[(x2-x1)² + (y2-y1)²]
   SCALE = GPS_distance / CAD_distance

2. ROTATION:
   GPS_bearing = atan2(lon2-lon1, lat2-lat1)
   CAD_angle = atan2(y2-y1, x2-x1)
   ROTATION = GPS_bearing - CAD_angle

3. TRANSFORM ANY POINT:
   x' = (x - x1) × SCALE × cos(ROTATION) - (y - y1) × SCALE × sin(ROTATION)
   y' = (x - x1) × SCALE × sin(ROTATION) + (y - y1) × SCALE × cos(ROTATION)
   
   lat_final = lat1 + (y' / 111000)
   lon_final = lon1 + (x' / (111000 × cos(lat1)))
```

---

## TROUBLESHOOTING (30 SECONDS)

| Problem | Fix |
|---------|-----|
| GPS won't lock | Move outside, away from trees. Wait 30s. Use high-accuracy mode. |
| CAD points look wrong | Verify you tapped SAME points as GPS points |
| Transform seems rotated | Check bearing calculation. Ensure CAD has correct orientation. |
| Waypoints too sparse | Ask for denser DXF (more lines) or interpolate in app |
| Rover drifts off path | Reduce `WP_RADIUS` to 0.2m, increase `NAVL1_PERIOD` to 3.0 |

---

## WHAT YOUR APP NEEDS (Dev Checklist)

```
✓ GPS capture (react-native-geolocation-service)
✓ DXF parser (dxf-parser npm)
✓ Affine math (native JavaScript)
✓ Map display (react-native-maps)
✓ Mission export (JSON → MAVLink format)
✓ WiFi send (TCP socket to rover)

Total code: ~200 lines (math + UI)
Library size: ~500KB
Memory needed: <50MB
```

---

## PRO TIPS

**🎯 Accuracy Tips:**
- Use 2 points as FAR APART as possible (longer baseline = less error)
- Use corners/marked points (easier to identify same point in CAD)
- Wait for RTK fix (green light, not yellow)
- Verify compass heading (bearing) makes sense

**⚡ Speed Tips:**
- Pre-open DXF file before capturing GPS
- Have client ready with laser pointer to exact start point
- Use highest accuracy GPS mode (not assisted)
- Test on simple shapes first (rectangles)

**🔒 Safety Tips:**
- Always have RC override ready
- Test with slow speed first (0.3 m/s)
- Have spotter watching rover
- Set geofence (±50m from site)

---

## EXAMPLE SCENARIO

```
CLIENT: "We need to mark parking lot lines"
         Shows you corner with laser pointer
         
YOU: 1. Stand at corner, tap GPS capture → Lat 13.0827, Lon 80.2709
     2. Walk to opposite corner → Lat 13.0835, Lon 80.2712
     3. Load parking_lot.dxf
     4. Tap same corner points in DXF drawing
     5. App calculates: Scale=7.96x, Rotation=5.7°
     6. Review map - lines align perfectly ✓
     7. Tap Export → Sent to rover
     8. Rover marks entire parking lot in 42 minutes
     9. Client happy ✓

TOTAL TIME: 8 minutes
ZERO LAPTOP NEEDED
```

---

## WHAT HAPPENS IF...

**No RTK signal?**
└─ Use standard GPS (±5m accuracy) → Works but less precise

**DXF file corrupted?**
└─ Ask client for SVG or PDF → Can extract points manually

**App crashes?**
└─ Fallback: Manual calculation using notes app + calculator

**Rover WiFi drops?**
└─ Save mission file → Transfer via USB later

**Client changes mind about location?**
└─ Repeat from Step 2 (2 min) with new GPS points

---

## MINIMUM VIABLE SOLUTION

If you want to code just the essentials TODAY:

```typescript
// 1. Capture 2 GPS points
const point1 = { lat: 13.0827, lon: 80.2709 };
const point2 = { lat: 13.0835, lon: 80.2712 };

// 2. Identify same in CAD
const cadPoint1 = { x: 0, y: 0 };
const cadPoint2 = { x: 3750, y: 2800 };

// 3. Calculate scale & rotation
const gpsDistance = haversine(point1, point2);  // 37.5m
const cadDistance = 4.712;  // meters
const scale = gpsDistance / cadDistance;  // 7.96

// 4. Transform all CAD points
const waypoints = cadEntities.map(point => ({
  lat: point1.lat + ((point.x - cadPoint1.x) * scale / 111000),
  lon: point1.lon + ((point.y - cadPoint1.y) * scale / 111000),
}));

// 5. Send to rover
sendMissionToRover(waypoints);
```

**That's it.** ~30 lines of code to solve the entire problem.

---

**REMEMBER:**
- GPS Point 1: Standing at start
- GPS Point 2: Walking to corner  
- Tap same corners in CAD
- App does math → Waypoints generated
- Done!

**TIME: 8 minutes. NO LAPTOP NEEDED.**
